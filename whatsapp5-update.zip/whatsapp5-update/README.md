# Almanzar Dubai (WhatsApp 5) — Integration Changes

This adds the Dubai WhatsApp number (+971 56 345 0844, phone_number_id 1236875606179466)
as a proper 5th account in the CRM, visible under company 12 (Almanzar) as "Almanzar Dubai".

## Option A — Apply the diff (fastest)

From the root of your local TELECRM repo:

```bash
git apply /path/to/CHANGES.diff
git add -A
git commit -m "Add Almanzar Dubai as WhatsApp account 5"
git push
```

If `git apply` complains about conflicts (unlikely, since these are small isolated edits),
use Option B instead.

## Option B — Copy files directly

Copy each file below into the matching path in your repo, overwriting the existing file:

- `server/src/controllers/whatsappController.ts`
- `src/App.tsx`
- `src/components/Layout/Sidebar.tsx`
- `src/views/whatsapp/WhatsAppInbox.tsx`

Then:

```bash
git add -A
git commit -m "Add Almanzar Dubai as WhatsApp account 5"
git push
```

Railway should auto-redeploy once you push to the branch it's tracking.

## What changed

1. **server/src/controllers/whatsappController.ts** — the inbox listing/filtering logic
   (`getPhoneId` / `getToken` / `getUserWACredentials`) now recognizes `account=4` as the
   Dubai number, reading `WHATSAPP_PHONE_NUMBER_ID_5`, `WA_ACCESS_TOKEN_5` (optional —
   falls back to `WA_ACCESS_TOKEN_4` if unset), and `WHATSAPP_BUSINESS_ACCOUNT_ID_5` from
   your Railway env vars.
2. **src/App.tsx** — new route `/app/whatsapp5` renders the inbox with `accountIndex={4}`.
3. **src/components/Layout/Sidebar.tsx** — adds an "Almanzar Dubai" link in the WhatsApp
   dropdown, shown only for `company_id === 12`.
4. **src/views/whatsapp/WhatsAppInbox.tsx** — registers phone_number_id
   `1236875606179466` as account index 4, updates labels/colors, and fixes the
   account-switcher button so it toggles WA4 ↔ WA5 instead of cycling into unrelated
   companies' slots.

## Env vars already set (from earlier)

```
WHATSAPP_PHONE_NUMBER_ID_5="1236875606179466"
WHATSAPP_BUSINESS_ACCOUNT_ID_5="964486646396502"
```

No further env changes are required — `WA_ACCESS_TOKEN_5` is optional and defaults to
reusing `WA_ACCESS_TOKEN_4`.

## After deploying

1. Log into the CRM as an admin for company 12.
2. Open the WhatsApp dropdown in the sidebar — you should now see both
   "Almanzar Primetech LLC" and "Almanzar Dubai".
3. Click "Almanzar Dubai" — the test messages sent earlier (e.g. "Hi" from
   917795808804) should now appear in this inbox.
