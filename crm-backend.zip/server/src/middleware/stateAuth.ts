import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

export interface StateAuthRequest extends Request {
  stateUser?: {
    id: number;
    email: string;
    role: string;
    state_id: number | null;
    coordinatorStates?: number[];
  };
}

const JWT_SECRET = process.env.JWT_SECRET || 'super_secret_key_change_this';

// Roles allowed, from highest to lowest
export const STATE_ROLES = ['master', 'admin', 'coordinator', 'state_head', 'sales_manager', 'sales_admin', 'team_member'];

export const authenticateState = (req: StateAuthRequest, res: Response, next: NextFunction) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'No token' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    // Hard boundary: a State CRM token must be explicitly marked as such.
    // This makes it structurally impossible for a regular-CRM token to be used here, or vice versa.
    if (decoded.crm !== 'state') {
      return res.status(403).json({ message: 'Invalid CRM context for this token' });
    }
    req.stateUser = {
      id: decoded.id,
      email: decoded.email,
      role: decoded.role,
      state_id: decoded.state_id ?? null,
      coordinatorStates: decoded.coordinatorStates || [],
    };
    next();
  } catch {
    res.status(401).json({ message: 'Invalid token' });
  }
};

export const requireStateRole = (...roles: string[]) => {
  return (req: StateAuthRequest, res: Response, next: NextFunction) => {
    if (!req.stateUser || !roles.includes(req.stateUser.role)) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    next();
  };
};

// Returns a SQL WHERE fragment + params to scope any query by state access.
// Master/Admin: no restriction.
// Coordinator: restricted to their assigned states.
// State Head / Sales Manager / Sales Admin / Team Member: restricted to their single state.
export const stateAccessFilter = (req: StateAuthRequest, column: string = 'state_id') => {
  const user = req.stateUser;
  if (!user) return { where: '1=0', params: [] as any[] };
  if (user.role === 'master' || user.role === 'admin') {
    return { where: '1=1', params: [] as any[] };
  }
  if (user.role === 'coordinator') {
    const states = user.coordinatorStates && user.coordinatorStates.length > 0 ? user.coordinatorStates : [-1];
    return { where: `${column} = ANY($STATE_PARAM)`, params: [states] };
  }
  // state_head, sales_manager, sales_admin, team_member
  return { where: `${column} = $STATE_PARAM`, params: [user.state_id ?? -1] };
};
