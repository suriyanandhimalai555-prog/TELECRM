import { Response } from 'express';
import db from '../../config/database';
import { StateAuthRequest, stateAccessFilter } from '../../middleware/stateAuth';

export const dashboardStats = async (req: StateAuthRequest, res: Response) => {
  try {
    const leadFilter = stateAccessFilter(req, 'state_id');
    const leadWhere = leadFilter.where.replace('$STATE_PARAM', '$1');

    const totalContactsResult = await db.query(
      `SELECT COUNT(*) FROM state_crm_leads WHERE ${leadWhere}`,
      leadFilter.params
    );
    const totalContacts = parseInt(totalContactsResult.rows[0].count, 10);

    const taskFilter = stateAccessFilter(req, 'state_id');
    const taskWhere = taskFilter.where.replace('$STATE_PARAM', '$1');
    const dailyTasksResult = await db.query(
      `SELECT COUNT(*) FROM state_crm_tasks WHERE ${taskWhere} AND status != 'completed'`,
      taskFilter.params
    );
    const dailyTasks = parseInt(dailyTasksResult.rows[0].count, 10);

    res.json({
      totalContacts,
      messagesToday: 0,
      unreadWhatsAppCount: 0,
      totalCalls: 0,
      totalDuration: 0,
      avgDuration: 0,
      dailyTasks,
      recentCalls: [],
      callTypeBreakdown: [],
    });
  } catch (err) {
    console.error('[StateCRM] dashboardStats error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};
