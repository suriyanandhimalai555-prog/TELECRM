import { Response } from 'express';
import db from '../../config/database';
import { StateAuthRequest, stateAccessFilter } from '../../middleware/stateAuth';


export const checkIn = async (req: StateAuthRequest, res: Response) => {
  const { lat, lng, photo } = req.body;
  const requester = req.stateUser!;
  try {
    const existing = await db.query(
      'SELECT * FROM state_crm_attendance WHERE user_id = $1 AND date = CURRENT_DATE AND check_out IS NULL',
      [requester.id]
    );
    if (existing.rows.length > 0) {
      return res.status(400).json({ message: 'Already checked in today' });
    }
    const { rows } = await db.query(
      `INSERT INTO state_crm_attendance (state_id, user_id, user_name, check_in, lat, lng, photo)
       VALUES ($1,$2,$3,NOW(),$4,$5,$6) RETURNING *`,
      [requester.state_id, requester.id, requester.email, lat || null, lng || null, photo || null]
    );
    res.json({ success: true, attendance: rows[0] });
  } catch (err: any) {
    console.error('[StateCRM] checkIn error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};export const checkOut = async (req: StateAuthRequest, res: Response) => {
  const requester = req.stateUser!;
  try {
    const { rows } = await db.query(
      `UPDATE state_crm_attendance SET check_out = NOW()
       WHERE user_id = $1 AND date = CURRENT_DATE AND check_out IS NULL RETURNING *`,
      [requester.id]
    );
    if (!rows.length) return res.status(400).json({ message: 'No active check-in found' });
    res.json({ success: true, attendance: rows[0] });
  } catch (err: any) {
    console.error('[StateCRM] checkOut error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const todayStatus = async (req: StateAuthRequest, res: Response) => {
  const requester = req.stateUser!;
  try {
    const { rows } = await db.query(
      'SELECT * FROM state_crm_attendance WHERE user_id = $1 AND date = CURRENT_DATE ORDER BY id DESC LIMIT 1',
      [requester.id]
    );
    res.json({ attendance: rows[0] || null });
  } catch (err: any) {
    console.error('[StateCRM] todayStatus error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const myHistory = async (req: StateAuthRequest, res: Response) => {
  const requester = req.stateUser!;
  try {
    const { rows } = await db.query(
      'SELECT * FROM state_crm_attendance WHERE user_id = $1 ORDER BY check_in DESC LIMIT 30',
      [requester.id]
    );
    res.json({ history: rows });
  } catch (err: any) {
    console.error('[StateCRM] myHistory error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const listAttendance = async (req: StateAuthRequest, res: Response) => {
  try {
    const { date } = req.query;
    const filter = stateAccessFilter(req, 'a.state_id');
    const where = filter.where.replace('$STATE_PARAM', '$1');
    let params = filter.params;
    let query = `
      SELECT a.*, u.name AS user_full_name, u.role, u.email
      FROM state_crm_attendance a
      LEFT JOIN state_crm_users u ON a.user_id = u.id
      WHERE ${where}
    `;
    if (date) {
      params = [...params, date];
      query += ` AND a.date = $${params.length}::date`;
    }
    query += ` ORDER BY a.check_in DESC`;
    const { rows } = await db.query(query, params);
    res.json({ attendance: rows });
  } catch (err: any) {
    console.error('[StateCRM] listAttendance error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};
