import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import db from '../../config/database';
import { StateAuthRequest, STATE_ROLES } from '../../middleware/stateAuth';

const JWT_SECRET = process.env.JWT_SECRET || 'super_secret_key_change_this';
const JWT_EXPIRE = process.env.JWT_EXPIRE || '7d';

const buildToken = async (user: any) => {
  let coordinatorStates: number[] = [];
  if (user.role === 'coordinator') {
    const r = await db.query('SELECT state_id FROM state_crm_coordinator_states WHERE user_id = $1', [user.id]);
    coordinatorStates = r.rows.map((row: any) => row.state_id);
  }
  return jwt.sign(
    {
      crm: 'state',
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      state_id: user.state_id,
      coordinatorStates,
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRE as any }
  );
};

// One-time bootstrap: only works when zero State CRM users exist yet.
// Creates the first account as 'master'. After that, use createUser instead.
export const bootstrapMaster = async (req: Request, res: Response) => {
  const { email, password, name } = req.body;
  try {
    const countResult = await db.query('SELECT COUNT(*) as count FROM state_crm_users');
    const count = parseInt(countResult.rows[0].count);
    if (count > 0) {
      return res.status(403).json({ message: 'State CRM already has users. Use an existing Master/Admin account to create more users.' });
    }
    const hashedPassword = bcrypt.hashSync(password, 10);
    const result = await db.query(
      `INSERT INTO state_crm_users (email, password, name, role) VALUES ($1, $2, $3, 'master') RETURNING id, email, name, role, state_id`,
      [email, hashedPassword, name]
    );
    const user = result.rows[0];
    const token = await buildToken(user);
    res.status(201).json({ token, user });
  } catch (error: any) {
    if (error.code === '23505') return res.status(400).json({ message: 'Email already exists' });
    console.error('[StateCRM] bootstrapMaster error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

export const login = async (req: Request, res: Response) => {
  const { email, password } = req.body;
  try {
    const result = await db.query('SELECT * FROM state_crm_users WHERE email = $1', [email]);
    if (result.rows.length === 0) return res.status(401).json({ message: 'Invalid credentials' });
    const user = result.rows[0];
    if (user.status === 'disabled') return res.status(403).json({ message: 'Account disabled' });
    const valid = bcrypt.compareSync(password, user.password);
    if (!valid) return res.status(401).json({ message: 'Invalid credentials' });
    const token = await buildToken(user);
    delete user.password;
    res.json({ token, user });
  } catch (error) {
    console.error('[StateCRM] login error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Master/Admin create users for any state; Coordinator can create within their assigned states.
export const createUser = async (req: StateAuthRequest, res: Response) => {
  const { email, password, name, role, state_id, reporting_to } = req.body;
  const requester = req.stateUser!;
  try {
    if (!STATE_ROLES.includes(role)) {
      return res.status(400).json({ message: 'Invalid role' });
    }
    if (requester.role !== 'master' && requester.role !== 'admin') {
      if (requester.role === 'coordinator') {
        const allowed = requester.coordinatorStates || [];
        if (!state_id || !allowed.includes(Number(state_id))) {
          return res.status(403).json({ message: 'You can only create users within your assigned states' });
        }
      } else {
        return res.status(403).json({ message: 'Forbidden' });
      }
    }
    const hashedPassword = bcrypt.hashSync(password, 10);
    const result = await db.query(
      `INSERT INTO state_crm_users (email, password, name, role, state_id, reporting_to) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id, email, name, role, state_id`,
      [email, hashedPassword, name, role, state_id || null, reporting_to || null]
    );
    res.status(201).json({ user: result.rows[0] });
  } catch (error: any) {
    if (error.code === '23505') return res.status(400).json({ message: 'Email already exists' });
    console.error('[StateCRM] createUser error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

export const listUsers = async (req: StateAuthRequest, res: Response) => {
  try {
    const requester = req.stateUser!;
    let where = '1=1';
    let params: any[] = [];
    if (requester.role === 'coordinator') {
      const states = requester.coordinatorStates && requester.coordinatorStates.length > 0 ? requester.coordinatorStates : [-1];
      where = 'state_id = ANY($1)';
      params = [states];
    } else if (requester.role !== 'master' && requester.role !== 'admin') {
      where = 'state_id = $1';
      params = [requester.state_id ?? -1];
    }
    const { rows } = await db.query(
      `SELECT id, email, name, role, state_id, reporting_to, status, created_at
       FROM state_crm_users WHERE ${where} ORDER BY created_at DESC`,
      params
    );
    res.json({ users: rows });
  } catch (error: any) {
    console.error('[StateCRM] listUsers error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

export const me = async (req: StateAuthRequest, res: Response) => {
  res.json({ user: req.stateUser });
};
