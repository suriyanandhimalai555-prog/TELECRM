import { Router } from 'express';
import { authenticateState, requireStateRole } from '../../middleware/stateAuth';
import { listStates, createState } from '../../controllers/state/stateController';
import { listLeads, createLead, updateLead, deleteLead } from '../../controllers/state/stateLeadController';
import { dashboardStats } from '../../controllers/state/stateReportController';
import { listTasks, createTask, updateTask, deleteTask } from '../../controllers/state/stateTaskController';
import { listContacts, createContact, updateContact, deleteContact } from '../../controllers/state/stateContactController';
import { listCalls, createCall } from '../../controllers/state/stateCallController';
import { listProjects, createProject, updateProject, deleteProject, getOwnerImpact, assignOwner } from '../../controllers/state/stateProjectController';
import { listNotes, createNote, deleteNote } from '../../controllers/state/stateNoteController';
import { checkIn, checkOut, todayStatus, listAttendance, myHistory } from '../../controllers/state/stateAttendanceController';

const router = Router();

router.get('/states', authenticateState, listStates);
router.post('/states', authenticateState, requireStateRole('master', 'admin'), createState);

router.get('/leads', authenticateState, listLeads);
router.post('/leads', authenticateState, createLead);
router.put('/leads/:id', authenticateState, updateLead);
router.delete('/leads/:id', authenticateState, deleteLead);
router.get('/reports/dashboard-stats', authenticateState, dashboardStats);
router.get('/tasks', authenticateState, listTasks);
router.post('/tasks', authenticateState, createTask);
router.put('/tasks/:id', authenticateState, updateTask);
router.delete('/tasks/:id', authenticateState, deleteTask);
router.get('/contacts', authenticateState, listContacts);
router.post('/contacts', authenticateState, createContact);
router.put('/contacts/:id', authenticateState, updateContact);
router.delete('/contacts/:id', authenticateState, deleteContact);

router.get('/calls', authenticateState, listCalls);
router.post('/calls', authenticateState, createCall);

router.get('/projects', authenticateState, listProjects);
router.post('/projects', authenticateState, requireStateRole('master', 'admin', 'coordinator'), createProject);
router.put('/projects/:id', authenticateState, requireStateRole('master', 'admin', 'coordinator'), updateProject);
router.delete('/projects/:id', authenticateState, requireStateRole('master', 'admin'), deleteProject);
router.get('/projects/:id/owner-impact', authenticateState, requireStateRole('master', 'admin', 'coordinator'), getOwnerImpact);
router.put('/projects/:id/assign-owner', authenticateState, requireStateRole('master', 'admin', 'coordinator'), assignOwner);

router.get('/notes', authenticateState, listNotes);
router.post('/notes', authenticateState, createNote);
router.delete('/notes/:id', authenticateState, deleteNote);

router.post('/attendance/checkin', authenticateState, checkIn);
router.post('/attendance/checkout', authenticateState, checkOut);
router.get('/attendance/today', authenticateState, todayStatus);
router.get('/attendance/all', authenticateState, listAttendance);
router.get('/attendance/history', authenticateState, myHistory);

export default router;
