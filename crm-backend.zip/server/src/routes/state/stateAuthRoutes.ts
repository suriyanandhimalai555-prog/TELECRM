import { Router } from 'express';
import { bootstrapMaster, login, createUser, listUsers, me } from '../../controllers/state/stateAuthController';
import { authenticateState, requireStateRole } from '../../middleware/stateAuth';

const router = Router();

router.post('/bootstrap-master', bootstrapMaster);
router.post('/login', login);
router.get('/me', authenticateState, me);
router.post('/users', authenticateState, requireStateRole('master', 'admin', 'coordinator'), createUser);
router.get('/users', authenticateState, listUsers);

export default router;
